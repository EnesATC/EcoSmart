--------------------------------------
-- Question 2 : Suppression des tables existantes si elles sont présentes
--------------------------------------
DROP TABLE IF EXISTS Mesure;
DROP TABLE IF EXISTS Facture;
DROP TABLE IF EXISTS Capteur_Actionneur;
DROP TABLE IF EXISTS Type_Capteur_Actionneur;
DROP TABLE IF EXISTS Piece;
DROP TABLE IF EXISTS Logement;

--------------------------------------
-- Question 3 : Création des tables de la base de données
--------------------------------------

-- Table Logement : stocke les informations de base de chaque logement
CREATE TABLE Logement (
    id_logement INTEGER PRIMARY KEY AUTOINCREMENT,
    adresse TEXT NOT NULL,
    numero_telephone TEXT,
    adresse_ip TEXT,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table Piece : représente les pièces de chaque logement
CREATE TABLE Piece (
    id_piece INTEGER PRIMARY KEY AUTOINCREMENT,
    id_logement INTEGER,
    nom TEXT NOT NULL,
    coordonnees TEXT,
    FOREIGN KEY (id_logement) REFERENCES Logement(id_logement) ON DELETE CASCADE
);

-- Table Type_Capteur_Actionneur : définit les types de capteurs/actionneurs
CREATE TABLE Type_Capteur_Actionneur (
    id_type INTEGER PRIMARY KEY AUTOINCREMENT,
    type_nom TEXT NOT NULL,
    unite_mesure TEXT,
    plage_precision TEXT
);

-- Table Capteur_Actionneur : liste les capteurs/actionneurs et leur emplacement
CREATE TABLE Capteur_Actionneur (
    id_capteur_actionneur INTEGER PRIMARY KEY AUTOINCREMENT,
    id_piece INTEGER,
    id_type INTEGER,
    reference_commerciale TEXT,
    port_communication TEXT,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_piece) REFERENCES Piece(id_piece) ON DELETE CASCADE,
    FOREIGN KEY (id_type) REFERENCES Type_Capteur_Actionneur(id_type) ON DELETE SET NULL
);

-- Table Mesure : enregistre les mesures prises par chaque capteur/actionneur
CREATE TABLE Mesure (
    id_mesure INTEGER PRIMARY KEY AUTOINCREMENT,
    id_capteur_actionneur INTEGER,
    valeur REAL NOT NULL,
    date_insertion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_capteur_actionneur) REFERENCES Capteur_Actionneur(id_capteur_actionneur) ON DELETE CASCADE
);

-- Table Facture : enregistre les factures associées à chaque logement
CREATE TABLE Facture (
    id_facture INTEGER PRIMARY KEY AUTOINCREMENT,
    id_logement INTEGER,
    type_facture TEXT NOT NULL,
    date DATE NOT NULL,
    montant REAL,
    valeur_consommation REAL,
    FOREIGN KEY (id_logement) REFERENCES Logement(id_logement) ON DELETE CASCADE
);

--------------------------------------
-- Question 4 : Insertion d'un logement et de 4 pièces associées
--------------------------------------

INSERT INTO Logement (adresse, numero_telephone, adresse_ip) 
VALUES ('123 Rue de l''Eco', '0123456789', '192.168.1.1');

INSERT INTO Piece (id_logement, nom, coordonnees) VALUES (1, 'Salon', '0,0,0');
INSERT INTO Piece (id_logement, nom, coordonnees) VALUES (1, 'Cuisine', '0,1,0');
INSERT INTO Piece (id_logement, nom, coordonnees) VALUES (1, 'Chambre', '1,0,0');
INSERT INTO Piece (id_logement, nom, coordonnees) VALUES (1, 'Salle de Bain', '1,1,0');

--------------------------------------
-- Question 5 : Création de 4 types de capteurs/actionneurs
--------------------------------------

INSERT INTO Type_Capteur_Actionneur (type_nom, unite_mesure, plage_precision) 
VALUES ('Température', '°C', '0 à 100'),
       ('Humidité', '%', '0 à 100'),
       ('Luminosité', 'Lux', '0 à 10000'),
       ('Consommation Électrique', 'kWh', '0 à 1000');
	   
	   
--------------------------------------
-- Question 6 : Insertion de 2 capteurs/actionneurs
--------------------------------------

INSERT INTO Capteur_Actionneur (id_piece, id_type, reference_commerciale, port_communication) 
VALUES (1, 1, 'TempSensor-X100', 'COM1'),
       (2, 2, 'HumSensor-Y200', 'COM2');

	      
--------------------------------------
-- Question 7 : Insertion de 2 mesures par capteur/actionneur
--------------------------------------

-- Mesures pour le capteur/actionneur 1 (TempSensor-X100)
INSERT INTO Mesure (id_capteur_actionneur, valeur) 
VALUES (1, 22.5),
       (1, 23.0);

-- Mesures pour le capteur/actionneur 2 (HumSensor-Y200)
INSERT INTO Mesure (id_capteur_actionneur, valeur) 
VALUES (2, 45.0),
       (2, 46.5);

--------------------------------------
-- Question 8 : Insertion de 4 factures
--------------------------------------

INSERT INTO Facture (id_logement, type_facture, date, montant, valeur_consommation)
VALUES (1, 'Eau', '2024-01-15', 30.0, 15.0),
       (1, 'Électricité', '2024-02-01', 50.0, 25.0),
       (1, 'Déchets', '2024-03-10', 20.0, 10.0),
       (1, 'Gaz', '2024-04-05', 40.0, 18.0);

	  