document.addEventListener("DOMContentLoaded", function () {
    const endpoint = "http://127.0.0.1:8000/comparatifs_mensuels/";
    const messageContainer = document.createElement("div");
    messageContainer.classList.add("validation-message");
    document.querySelector(".comparatifs").appendChild(messageContainer);

    function showMessage(message, type) {
        messageContainer.textContent = message;
        messageContainer.className = `validation-message ${type}`;
        setTimeout(() => {
            messageContainer.textContent = "";
            messageContainer.className = "validation-message";
        }, 3000);
    }

    function loadComparatifs() {
        fetch(endpoint)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur lors de la récupération des comparatifs mensuels.");
                }
                return response.json();
            })
            .then(data => {
                drawChart(data);
                showMessage("Comparatifs mensuels chargés avec succès !", "success");
            })
            .catch(error => {
                console.error(error);
                showMessage("Erreur lors du chargement des comparatifs mensuels.", "error");
            });
    }

    function drawChart(data) {
        
        google.charts.load('current', { packages: ['corechart'] });

        google.charts.setOnLoadCallback(() => {
            const moisSet = new Set();
            data.forEach(item => moisSet.add(item.mois));
            const moisList = Array.from(moisSet).sort();

            const typesSet = new Set();
            data.forEach(item => typesSet.add(item.type_facture));
            const typesList = Array.from(typesSet);

            const chartData = [['Mois', ...typesList]];

            moisList.forEach(mois => {
                const row = [mois];
                typesList.forEach(type => {
                    const facture = data.find(item => item.mois === mois && item.type_facture === type);
                    row.push(facture ? facture.total : 0);
                });
                chartData.push(row);
            });

            const dataTable = google.visualization.arrayToDataTable(chartData);

            const options = {
                title: 'Comparatif Économique des Consommations par Mois',
                hAxis: {
                    title: 'Mois',
                    textStyle: { color: '#0b3e27', fontSize: 12 },
                    titleTextStyle: { color: '#0b3e27', fontSize: 14, bold: true }
                },
                vAxis: {
                    title: 'Montant (€)',
                    textStyle: { color: '#0b3e27', fontSize: 12 },
                    titleTextStyle: { color: '#0b3e27', fontSize: 14, bold: true }
                },
                colors: ['#197149', '#88c57f', '#d4e9d4', '#0b3e27'], 
                backgroundColor: '#f9f9f9',
                legend: { position: 'top', textStyle: { color: '#333333', fontSize: 12 } },
                isStacked: true, 
                chartArea: { width: '70%', height: '70%' }
            };

            const chart = new google.visualization.ColumnChart(document.getElementById('comparatifChart'));
            chart.draw(dataTable, options);
        });
    }

    loadComparatifs();
});
