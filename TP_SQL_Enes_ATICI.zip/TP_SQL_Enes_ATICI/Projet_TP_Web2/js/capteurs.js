document.addEventListener("DOMContentLoaded", function () {
    const endpoint = "http://127.0.0.1:8000/capteurs/";
    const tableBody = document.querySelector(".capteurs-table tbody");
    const messageContainer = document.createElement("div");
    messageContainer.classList.add("validation-message");
    document.querySelector(".capteurs").appendChild(messageContainer);

    const pieceMapping = {
        1: "Salon",
        2: "Cuisine",
        3: "Chambre",
        4: "Salle de Bain"
    };

    const typeMapping = {
        1: "Température",
        2: "Humidité",
        3: "Luminosité",
        4: "Consommation électrique"
    };

    function showMessage(message, type, autoHide = false, duration = 1000) {
        messageContainer.textContent = message;
        messageContainer.className = `validation-message ${type}`;

        if (autoHide) {
            setTimeout(() => {
                if (messageContainer.textContent === message) {
                    messageContainer.textContent = "";
                    messageContainer.className = "validation-message";
                }
            }, duration);
        }
    }

    function loadCapteurs() {
        showMessage("Chargement des capteurs...", "info", true);
        tableBody.innerHTML = "<tr><td colspan='6'>Chargement des données...</td></tr>";
        fetch(endpoint)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur lors de la récupération des capteurs.");
                }
                return response.json();
            })
            .then(data => {
                tableBody.innerHTML = "";
                if (data.length === 0) {
                    tableBody.innerHTML = "<tr><td colspan='6'>Aucun capteur disponible.</td></tr>";
                    showMessage("Aucun capteur disponible.", "info");
                    return;
                }

        
                const rows = data.map(capteur => {
                    return `
                        <tr>
                            <td>${capteur.id_capteur_actionneur}</td>
                            <td>${capteur.reference_commerciale}</td>
                            <td>${capteur.port_communication}</td>
                            <td>${pieceMapping[capteur.id_piece] || "Non spécifié"}</td>
                            <td>${typeMapping[capteur.id_type] || "Non spécifié"}</td>
                            <td>
                                <button class="btn-delete" data-id="${capteur.id_capteur_actionneur}" aria-label="Supprimer le capteur ${capteur.reference_commerciale}">Supprimer</button>
                            </td>
                        </tr>
                    `;
                }).join("");
                tableBody.innerHTML = rows;
                addEventListeners();
                
            })
            .catch(error => {
                console.error(error);
                tableBody.innerHTML = "<tr><td colspan='6'>Erreur lors du chargement des capteurs.</td></tr>";
                showMessage("Erreur lors du chargement des capteurs.", "error", true);
            });
    }

    function deleteCapteur(id) {
        fetch(`${endpoint}${id}`, {
            method: "DELETE"
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur lors de la suppression du capteur.");
                }
                showMessage("Capteur supprimé avec succès !", "success", true);
                loadCapteurs();
            })
            .catch(error => {
                console.error(error);
                showMessage("Erreur lors de la suppression du capteur.", "error", true);
            });
    }

    function addEventListeners() {
        const deleteButtons = document.querySelectorAll(".btn-delete");
        deleteButtons.forEach(button => {
            button.addEventListener("click", function () {
                const id = this.dataset.id;
                if (confirm("Êtes-vous sûr de vouloir supprimer ce capteur ?")) {
                    deleteCapteur(id);
                }
            });
        });
    }

    loadCapteurs();
});
