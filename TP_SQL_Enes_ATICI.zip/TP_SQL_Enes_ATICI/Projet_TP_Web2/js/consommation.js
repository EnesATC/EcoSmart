document.addEventListener("DOMContentLoaded", function () {
    const endpointFactures = "http://127.0.0.1:8000/factures/";
    const endpointFacturesData = "http://127.0.0.1:8000/factures_data/";
    const tableBodyDisplay = document.querySelector(".factures-display-table tbody");

    const messageContainer = document.createElement("div");
    messageContainer.classList.add("validation-message");

    const consommationSection = document.querySelector(".consommation");
    consommationSection.appendChild(messageContainer);

    function showMessage(message, type, autoHide = false, duration = 5000) {
        messageContainer.textContent = message;
        messageContainer.className = `validation-message ${type}`;
        if (autoHide) {
            setTimeout(() => {
                if (messageContainer.textContent === message) {
                    messageContainer.textContent = "";
                    messageContainer.className = "validation-message";
                }
            }, duration);
        }
    }

    function loadFactures() {
        fetch(endpointFactures)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur lors de la récupération des factures.");
                }
                return response.json();
            })
            .then(data => {
                tableBodyDisplay.innerHTML = "";
                if (data.length === 0) {
                    tableBodyDisplay.innerHTML = "<tr><td colspan='6'>Aucune facture disponible.</td></tr>";
                    showMessage("Aucune facture disponible.", "info");
                    return;
                }
                const rows = data.map((facture, index) => {
                    return `
                        <tr>
                            <td>${index + 1}</td>
                            <td>${facture.type_facture}</td>
                            <td>${facture.date}</td>
                            <td>${facture.montant.toFixed(2)} €</td>
                            <td>${facture.valeur_consommation.toFixed(2)}</td>
                            <td>
                                <button class="btn-delete" data-id="${facture.id_facture}" aria-label="Supprimer la facture numéro ${facture.id_facture}">Supprimer</button>
                            </td>
                        </tr>
                    `;
                }).join("");
                tableBodyDisplay.innerHTML = rows;
                addDeleteListeners(); 
            })
            .catch(error => {
                console.error(error);
                tableBodyDisplay.innerHTML = "<tr><td colspan='6'>Erreur lors du chargement des factures.</td></tr>";
                showMessage("Erreur lors du chargement des factures.", "error", true);
            });
    }

    function addFacture() {
        const type = document.getElementById("facture-type").value;
        const date = document.getElementById("facture-date").value;
        const montant = parseFloat(document.getElementById("facture-montant").value);
        const consommation = parseFloat(document.getElementById("facture-consommation").value);

        if (!type || !date || isNaN(montant) || isNaN(consommation)) {
            showMessage("Veuillez remplir tous les champs obligatoires.", "error", true);
            return;
        }

        const facture = {
            id_logement: 1,
            type_facture: type,
            date: date,
            montant: montant,
            valeur_consommation: consommation
        };

        fetch(endpointFactures, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(facture)
        })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => {
                        throw new Error(`Erreur ${response.status}: ${err.detail || "Erreur inconnue"}`);
                    });
                }
                return response.json();
            })
            .then(() => {
                showMessage("Facture ajoutée avec succès !", "success", true);

                document.getElementById("facture-type").value = "";
                document.getElementById("facture-date").value = "";
                document.getElementById("facture-montant").value = "";
                document.getElementById("facture-consommation").value = "";
                loadFactures(); 
                loadFacturesData(); 
            })
            .catch(error => {
                console.error(error);
                showMessage(`Erreur lors de l'ajout de la facture : ${error.message}`, "error", true);
            });
    }

    
    function deleteFacture(id) {
        fetch(`${endpointFactures}${id}`, {
            method: "DELETE"
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur lors de la suppression de la facture.");
                }
                showMessage("Facture supprimée avec succès !", "success", true);
                loadFactures();
                loadFacturesData();
            })
            .catch(error => {
                console.error(error);
                showMessage("Erreur lors de la suppression de la facture.", "error", true);
            });
    }

   

    function addDeleteListeners() {
        const deleteButtons = document.querySelectorAll(".btn-delete");
        deleteButtons.forEach(button => {
            button.addEventListener("click", function () {
                const id = this.dataset.id;
                if (confirm("Êtes-vous sûr de vouloir supprimer cette facture ?")) {
                    deleteFacture(id);
                }
            });
        });
    }

    
    function loadFacturesData(period = "") {
       
        const url = period ? `${endpointFacturesData}?period=${period}` : endpointFacturesData;

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur lors de la récupération des données des factures.");
                }
                return response.json();
            })
            .then(data => drawChart(data, period))
            .catch(error => {
                console.error("Erreur lors du chargement des données pour le camembert :", error);
                showMessage("Erreur lors de la récupération des données.", "error", true);
            });
    }

   

    function drawChart(data, period) {
        google.charts.load('current', { packages: ['corechart'] });
        google.charts.setOnLoadCallback(() => {
            const chartData = [['Type de Facture', 'Montant Total']];
            data.forEach(item => {
                chartData.push([item.type_facture, item.total]);
            });

            const options = {
                title: `Répartition de la Consommation (${period || "Totale"})`,
                pieHole: 0.4,
                colors: ['#0b3e27', '#197149', '#88c57f', '#d4e9d4'], 
                backgroundColor: '#f9f9f9',
                titleTextStyle: {
                    color: '#0b3e27',
                    fontSize: 18,
                    bold: true,
                },
                legend: {
                    textStyle: {
                        color: '#333333',
                        fontSize: 14,
                    },
                },
            };

            const chart = new google.visualization.PieChart(document.getElementById('factureChart'));
            chart.draw(google.visualization.arrayToDataTable(chartData), options);
        });
    }

   
    document.getElementById("add-facture").addEventListener("click", addFacture);
    document.getElementById("consommation-day").addEventListener("click", () => loadFacturesData("jour"));
    document.getElementById("consommation-week").addEventListener("click", () => loadFacturesData("semaine"));
    document.getElementById("consommation-month").addEventListener("click", () => loadFacturesData("mois"));
    document.getElementById("consommation-year").addEventListener("click", () => loadFacturesData("année"));

   
    loadFactures();
    loadFacturesData();
});
