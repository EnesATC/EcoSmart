document.addEventListener("DOMContentLoaded", function () {
    const endpoint = "http://127.0.0.1:8000/capteurs/";
    const tableBody = document.querySelector(".configuration-table tbody");
    const messageContainer = document.createElement("div");
    messageContainer.classList.add("validation-message");
    document.querySelector(".configuration").appendChild(messageContainer);

    function showMessage(message, type, autoHide = false, duration = 10000) {
        messageContainer.textContent = message;
        messageContainer.className = `validation-message ${type}`;

        if (autoHide) {
            setTimeout(() => {
                if (messageContainer.textContent === message) {
                    messageContainer.textContent = "";
                    messageContainer.className = "validation-message";
                }
            }, duration);
        }
    }

    function validateForm(capteur) {
        if (!capteur.id_piece || !capteur.id_type || !capteur.reference_commerciale || !capteur.port_communication) {
            showMessage("Veuillez remplir tous les champs obligatoires.", "error", true);
            return false;
        }
        return true;
    }

    function loadConfigurationTable() {
        tableBody.innerHTML = `
            <tr>
                <td>
                    <label for="piece">Pièce</label>
                    <select id="piece" required>
                        <option value="">--Sélectionnez--</option>
                        <option value="1">Salon</option>
                        <option value="2">Cuisine</option>
                        <option value="3">Chambre</option>
                        <option value="4">Salle de Bain</option>
                    </select>
                </td>
                <td>
                    <label for="type">Type de Capteur</label>
                    <select id="type" required>
                        <option value="">--Sélectionnez--</option>
                        <option value="1">Température</option>
                        <option value="2">Humidité</option>
                        <option value="3">Luminosité</option>
                        <option value="4">Consommation électrique</option>
                    </select>
                </td>
                <td>
                    <label for="reference">Référence Commerciale</label>
                    <input type="text" id="reference" placeholder="Ex : TempSensor-X100" required />
                </td>
                <td>
                    <label for="port">Port de Communication</label>
                    <input type="text" id="port" placeholder="Ex : COM1" required />
                </td>
                <td>
                    <button class="btn-add" aria-label="Ajouter un nouveau capteur">Ajouter</button>
                </td>
            </tr>
        `;

        document.querySelector(".btn-add").addEventListener("click", addCapteur);
    }

    function addCapteur() {
        const pieceSelect = document.getElementById("piece");
        const typeSelect = document.getElementById("type");
        const referenceInput = document.getElementById("reference");
        const portInput = document.getElementById("port");

        const capteur = {
            id_piece: parseInt(pieceSelect.value, 10),
            id_type: parseInt(typeSelect.value, 10),
            reference_commerciale: referenceInput.value.trim(),
            port_communication: portInput.value.trim()
        };

        if (!validateForm(capteur)) return;

        fetch(endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(capteur)
        })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => {
                        throw new Error(`Erreur ${response.status}: ${err.detail || "Erreur inconnue"}`);
                    });
                }
                return response.json();
            })
            .then(() => {
                showMessage("Capteur ajouté avec succès !", "success", true);
                pieceSelect.value = "";
                typeSelect.value = "";
                referenceInput.value = "";
                portInput.value = "";
            })
            .catch(error => {
                console.error(error);
                showMessage(`Erreur lors de l'ajout du capteur : ${error.message}`, "error", true);
            });
    }

    loadConfigurationTable();
});
