from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlite3
from datetime import datetime
from typing import Optional, List

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500"],  
    allow_credentials=True,
    allow_methods=["*"],  
    allow_headers=["*"], 
)

class Capteur(BaseModel):
    id_piece: int
    id_type: int
    reference_commerciale: str
    port_communication: str

class Mesure(BaseModel):
    id_capteur_actionneur: int
    valeur: float

class Facture(BaseModel):
    id_logement: int
    type_facture: str
    date: str  
    montant: float
    valeur_consommation: Optional[float] = None

def get_db_connection():
    conn = sqlite3.connect("logement.db")
    conn.row_factory = sqlite3.Row
    return conn

# ------------------ CAPTEURS ------------------------------------------------

@app.get("/capteurs/")
def get_capteurs():
    conn = get_db_connection()
    capteurs = conn.execute("SELECT * FROM Capteur_Actionneur").fetchall()
    conn.close()
    return [dict(capteur) for capteur in capteurs]

@app.post("/capteurs/")
def add_capteur(capteur: Capteur):
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO Capteur_Actionneur (id_piece, id_type, reference_commerciale, port_communication, date_insertion) VALUES (?, ?, ?, ?, ?)",
        (capteur.id_piece, capteur.id_type, capteur.reference_commerciale, capteur.port_communication, datetime.now()),
    )
    conn.commit()
    conn.close()
    return {"message": "Capteur ajouté avec succès"}

@app.delete("/capteurs/{capteur_id}")
def delete_capteur(capteur_id: int):
    conn = get_db_connection()
    cursor = conn.execute("DELETE FROM Capteur_Actionneur WHERE id_capteur_actionneur = ?", (capteur_id,))
    conn.commit()
    conn.close()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Capteur non trouvé")
    return {"message": "Capteur supprimé avec succès"}

# ------------------ MESURES ---------------------------------------------

@app.get("/mesures/")
def get_mesures():
    conn = get_db_connection()
    mesures = conn.execute("SELECT * FROM Mesure").fetchall()
    conn.close()
    return [dict(mesure) for mesure in mesures]

@app.post("/mesures/")
def add_mesure(mesure: Mesure):
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO Mesure (id_capteur_actionneur, valeur, date_insertion) VALUES (?, ?, ?)",
        (mesure.id_capteur_actionneur, mesure.valeur, datetime.now()),
    )
    conn.commit()
    conn.close()
    return {"message": "Mesure ajoutée avec succès"}

# ------------------ FACTURES --------------------------------

@app.get("/factures/")
def get_factures():
    conn = get_db_connection()
    factures = conn.execute("SELECT * FROM Facture").fetchall()
    conn.close()
    return [dict(facture) for facture in factures]

@app.post("/factures/")
def add_facture(facture: Facture):
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO Facture (id_logement, type_facture, date, montant, valeur_consommation) VALUES (?, ?, ?, ?, ?)",
        (facture.id_logement, facture.type_facture, facture.date, facture.montant, facture.valeur_consommation),
    )
    conn.commit()
    conn.close()
    return {"message": "Facture ajoutée avec succès"}

@app.delete("/factures/{facture_id}")
def delete_facture(facture_id: int):
    conn = get_db_connection()
    cursor = conn.execute("DELETE FROM Facture WHERE id_facture = ?", (facture_id,))
    conn.commit()
    conn.close()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Facture non trouvée")
    return {"message": "Facture supprimée avec succès"}

# ------------------ GENERATION DE DONNEES FICTIVES -----------------------------------------

@app.post("/generate_fake_data/")
def generate_fake_data():
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO Mesure (id_capteur_actionneur, valeur, date_insertion) VALUES (1, 25.5, ?)",
        (datetime.now(),),
    )
    conn.commit()
    conn.close()
    return {"message": "Données factices générées avec succès"}

# ------------------ FACTURES DATA POUR CAMEMBERT ------------------

@app.get("/factures_data/")
def get_factures_data():
    conn = get_db_connection()
    factures = conn.execute("SELECT type_facture, SUM(montant) as total FROM Facture GROUP BY type_facture").fetchall()
    conn.close()
    return [{"type_facture": facture["type_facture"], "total": facture["total"]} for facture in factures]

# ------------------ COMPARATIFS ECONOMIQUES MENSUELS ------------------

@app.get("/comparatifs_mensuels/", response_model=List[dict])
def get_comparatifs_mensuels():
    conn = get_db_connection()
    try:
        comparatifs_mensuels = conn.execute("""
            SELECT 
                strftime('%Y-%m', date) as mois,
                type_facture,
                SUM(montant) as total
            FROM Facture
            GROUP BY mois, type_facture
            ORDER BY mois ASC
        """).fetchall()
        conn.close()
        return [{"mois": row["mois"], "type_facture": row["type_facture"], "total": row["total"]} for row in comparatifs_mensuels]
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=500, detail=str(e))
